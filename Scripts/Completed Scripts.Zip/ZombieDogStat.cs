using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieDogStat : MonoBehaviour
{
    // public Animator zombieAnimator;
    public float health = 100f;
    public float damage = 20f;
    public float speed = 2f;
    
    // 공격속도 추가해야함
}
